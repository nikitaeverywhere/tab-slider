(function () {
'use strict';

function moveTab$1(id, index, callback) {
  chrome.tabs.move(
    id,
    {
      index: index,
    },
    callback || (() => {})
  );
}

function onTabActivated(callback) {
  chrome.tabs.onActivated.addListener(({ id }) => callback(id));
}

function onTabCreated(callback) {
  chrome.tabs.onCreated.addListener((tab) => callback(tab));
}

function groupTabs(tabIds, groupId, callback) {
  chrome.tabs.group({ tabIds, groupId }, callback);
}

function removeTab(ids, callback) {
  chrome.tabs.remove(ids, callback);
}

function getAllTabs(callback) {
  chrome.tabs.query(
    {
      currentWindow: true,
    },
    (tabs) => callback(tabs)
  );
}



function getActiveTab(callback) {
  chrome.tabs.query(
    {
      active: true,
      currentWindow: true,
    },
    ([tab]) => callback(tab || null)
  );
}

/**
 * @param {string} key
 * @param {string} value
 * @returns {Promise}
 */


/**
 * @param {string} key
 * @returns {Promise<string | undefined>}
 */
async function getStorage(key) {
  return ((await chrome.storage.local.get([key])) || {})[key];
}

/**
 * @param {string} key
 * @returns {Promise<boolean>}
 */
async function hasStorageKey(key) {
  const result = await chrome.storage.local.get([key]);
  return Object.prototype.hasOwnProperty.call(result, key);
}

// This comments are preprocessed and in final browser bundle will appear an appropriate API.
const DEFAULT_DELAY = 1;
const DEFAULT_MOVE_PINNED_TABS = true;
const DEFAULT_MAX_TABS = 25;

async function getDelay() {
  return (await hasStorageKey("delay"))
    ? parseFloat(await getStorage("delay"))
    : DEFAULT_DELAY;
}


async function getMovePinnedTabs() {
  return (await hasStorageKey("movePinnedTabs"))
    ? (await getStorage("movePinnedTabs")) === "true"
    : DEFAULT_MOVE_PINNED_TABS;
}


async function getMaxTabs() {
  return (await hasStorageKey("maxTabs"))
    ? parseInt(await getStorage("maxTabs"))
    : DEFAULT_MAX_TABS;
}

// This comments are preprocessed and in final browser bundle will appear an appropriate API.
let timeout;
const byIndexAsc = (a, b) => a.index - b.index;

onTabActivated(async () => {
  clearTimeout(timeout);
  timeout = setTimeout(triggerTabSlide, (await getDelay()) * 1000);
});

onTabCreated((tab) => {
  getActiveTab(async (activeTab) => {
    // Opera does not set tab.active immediately onTabCreated

    if (activeTab.id !== tab.id) return;

    await moveTab(tab);
  });
});

function removeOverflownTabs() {
  getAllTabs(async (tabs) => {
    const maxTabs = await getMaxTabs();
    if (tabs.length > maxTabs) {
      const lastTabs = tabs.sort(byIndexAsc).slice(maxTabs);
      if (lastTabs.length) {
        await removeTab(lastTabs.map((tab) => tab.id));
      }
    }
  });
}

function moveTab(tab) {
  getAllTabs(async (tabs) => {
    if (tab.pinned && !(await getMovePinnedTabs())) return;

    const pinnedTabs = tabs.filter((tab) => tab.pinned);
    if (tab.groupId > 0 && !tab.pinned) {
      // Since Chrome 88; Pinned tabs cannot be in the group.
      // However, the condition above additionally restricts it.
      const groupId = tab.groupId;
      const allTabsInGroup = [tab].concat(
        tabs
          .filter((t) => t.groupId === tab.groupId && t.id !== tab.id)
          .sort(byIndexAsc)
      );
      const tabIds = allTabsInGroup.map((tab) => tab.id);
      await moveTab$1(tabIds, pinnedTabs.length, async () => {
        // Because the group falls apart, it has to be grouped again.
        await groupTabs(tabIds, groupId);
        removeOverflownTabs();
      });
    } else {
      await moveTab$1(
        tab.id,
        tab.pinned ? pinnedTabs.length - 1 : pinnedTabs.length,
        removeOverflownTabs
      );
    }
  });
}

async function triggerTabSlide() {
  return await getActiveTab((tab) => tab && moveTab(tab));
}

}());
