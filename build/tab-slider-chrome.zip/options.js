(function () {
'use strict';

const defaultDelay = 1;
const movePinnedTabs = true;
const maxTabs = 999;

function getDelay () {
	return localStorage.hasOwnProperty("delay")
		? parseFloat(localStorage["delay"])
		: defaultDelay;
}
function setDelay (number) {
	return localStorage["delay"] = number > 0.1 ? number : 0.1;
}

function getMovePinnedTabs () {
	return localStorage.hasOwnProperty("movePinnedTabs")
		? localStorage["movePinnedTabs"] === "true"
		: movePinnedTabs;
}
function setMovePinnedTabs (boolean) {
	return localStorage["movePinnedTabs"] = !!boolean;
}

function getMaxTabs () {
	return localStorage.hasOwnProperty("maxTabs")
		? parseInt(localStorage["maxTabs"])
		: maxTabs;
}
function setMaxTabs (number) {
	return localStorage["maxTabs"] = Math.max(2, +number);
}

window.addEventListener("load", () => {

	const delayElement = document.getElementById("delay");
	const maxTabsElement = document.getElementById("maxTabs");
	const movePinnedTabsElement = document.getElementById("movePinnedTabs");

	delayElement.value = getDelay();
	maxTabsElement.value = getMaxTabs();
	movePinnedTabsElement.checked = getMovePinnedTabs();

	delayElement.addEventListener("change", ({ target }) => {
		target.value = setDelay(target.value);
	});
	maxTabsElement.addEventListener("change", ({ target }) => {
		target.value = setMaxTabs(target.value);
	});
	movePinnedTabsElement.addEventListener("change", ({ target }) => {
		target.checked = setMovePinnedTabs(target.checked);
	});

});

}());
