(function () {
'use strict';

function moveTab$1 (id, index, callback) {

	browser.tabs.move(id, {
		index: index
	}).then(() => callback ? callback() : null);

}

function onTabActivated (callback) {
	browser.tabs.onActivated.addListener(({ id }) => callback(id));
}

function onTabCreated (callback) {
	browser.tabs.onCreated.addListener((tab) => callback(tab));
}

function getPinnedTabsNumber (callback) {

	browser.tabs.query({
		currentWindow: true,
		pinned: true
	}, ({ length }) => callback(length));

}

function getActiveTab (callback) {

	browser.tabs.query({
		active: true,
		currentWindow: true
	}).then(([ tab ]) => callback(tab || null));

}

const defaultDelay = 1;
const movePinnedTabs = true;

function getDelay () {
	return localStorage.hasOwnProperty("delay")
		? parseFloat(localStorage["delay"])
		: defaultDelay;
}


function getMovePinnedTabs () {
	return localStorage.hasOwnProperty("movePinnedTabs")
		? localStorage["movePinnedTabs"] === "true"
		: movePinnedTabs;
}

// This comments are preprocessed and in final browser bundle will appear an appropriate API.
let timeout;

onTabActivated(() => {

	clearTimeout(timeout);
	timeout = setTimeout(triggerTabSlide, getDelay() * 1000);

});

onTabCreated((tab) => {

	getActiveTab((activeTab) => { // Opera does not set tab.active immediately onTabCreated

		if (activeTab.id !== tab.id)
			return;

		moveTab(tab);

	});

});

function moveTab (tab) {
	getPinnedTabsNumber((pinnedTabs) => {
		if (tab.pinned && !getMovePinnedTabs())
			return;
		moveTab$1(tab.id, tab.pinned ? pinnedTabs - 1 : pinnedTabs);
	});
}

function triggerTabSlide () {
	getActiveTab((tab) => tab && moveTab(tab));
}

}());
