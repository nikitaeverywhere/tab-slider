(function () {
'use strict';

function move (id, index, callback) {

	browser.tabs.move(id, {
		index: index
	}).then(() => callback ? callback() : null);

}

function onTabActivated (callback) {
	browser.tabs.onActivated.addListener(({ id }) => callback(id));
}

function onTabCreated (callback) {
	browser.tabs.onCreated.addListener((tab) => callback(tab));
}

function getPinnedTabsNumber (callback) {

	browser.tabs.query({
		currentWindow: true,
		pinned: true
	}, ({ length }) => callback(length));

}

function getActiveTab (callback) {

	browser.tabs.query({
		active: true,
		currentWindow: true
	}).then(([ tab ]) => callback(tab || null));

}

const defaultDelay = 1;

// This comments are preprocessed and in final browser bundle will go an appropriate API.
let timeout;

onTabActivated(() => {

	clearTimeout(timeout);
	timeout = setTimeout(
		triggerTabSlide,
		(localStorage.hasOwnProperty("delay") ? localStorage["delay"] : defaultDelay) * 1000
	);

});

onTabCreated((tab) => {

	getActiveTab((activeTab) => { // Opera does not set tab.active immediately onTabCreated

		if (activeTab.id !== tab.id)
			return;

		moveTabLeft(tab.id);

	});

});

function moveTabLeft (id) {
	getPinnedTabsNumber((pinnedTabs) => move(id, pinnedTabs));
}

function triggerTabSlide () {
	getActiveTab((tab) => tab && tab.index !== 0 && moveTabLeft(tab.id));
}

}());
