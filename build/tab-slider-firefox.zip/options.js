(function () {
'use strict';

/**
 * @param {string} key
 * @param {string} value
 * @returns {Promise}
 */
async function setStorage(key, value) {
  return browser.storage.local.set({ [key]: value });
}

/**
 * @param {string} key
 * @returns {Promise<string | undefined>}
 */
async function getStorage(key) {
  const result = await browser.storage.local.get([key]);
  return result[key];
}

/**
 * @param {string} key
 * @returns {Promise<boolean>}
 */
async function hasStorageKey(key) {
  const result = await browser.storage.local.get([key]);
  return Object.prototype.hasOwnProperty.call(result, key);
}

// This comments are preprocessed and in final browser bundle will appear an appropriate API.
const DEFAULT_DELAY = 1;
const DEFAULT_MOVE_PINNED_TABS = true;
const DEFAULT_MAX_TABS = 25;

async function getDelay() {
  return (await hasStorageKey("delay"))
    ? parseFloat(await getStorage("delay"))
    : DEFAULT_DELAY;
}
async function setDelay(number) {
  await setStorage("delay", number > 0.1 ? number : 0.1);
  return number;
}

async function getMovePinnedTabs() {
  return (await hasStorageKey("movePinnedTabs"))
    ? (await getStorage("movePinnedTabs")) === "true"
    : DEFAULT_MOVE_PINNED_TABS;
}
async function setMovePinnedTabs(boolean) {
  await setStorage("movePinnedTabs", !!boolean);
  return !!boolean;
}

async function getMaxTabs() {
  return (await hasStorageKey("maxTabs"))
    ? parseInt(await getStorage("maxTabs"))
    : DEFAULT_MAX_TABS;
}
async function setMaxTabs(number) {
  await setStorage("maxTabs", Math.max(2, +number));
  return number;
}

window.addEventListener("load", async () => {
  const version = document.getElementById("version");
  const delayElement = document.getElementById("delay");
  const maxTabsElement = document.getElementById("maxTabs");
  const movePinnedTabsElement = document.getElementById("movePinnedTabs");

  delayElement.value = await getDelay();
  maxTabsElement.value = await getMaxTabs();
  movePinnedTabsElement.checked = await getMovePinnedTabs();
  version.textContent = "v2.1.0";

  delayElement.addEventListener("change", async ({ target }) => {
    target.value = await setDelay(target.value);
  });
  maxTabsElement.addEventListener("change", async ({ target }) => {
    target.value = await setMaxTabs(target.value);
  });
  movePinnedTabsElement.addEventListener("change", async ({ target }) => {
    target.checked = await setMovePinnedTabs(target.checked);
  });
});

}());
