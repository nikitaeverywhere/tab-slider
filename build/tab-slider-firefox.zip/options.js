(function () {
'use strict';

const defaultDelay = 1;
const movePinnedTabs = true;

function getDelay () {
	return localStorage.hasOwnProperty("delay")
		? parseFloat(localStorage["delay"])
		: defaultDelay;
}
function setDelay (number) {
	return localStorage["delay"] = number > 0.1 ? number : 0.1;
}

function getMovePinnedTabs () {
	return localStorage.hasOwnProperty("movePinnedTabs")
		? localStorage["movePinnedTabs"] === "true"
		: movePinnedTabs;
}
function setMovePinnedTabs (boolean) {
	return localStorage["movePinnedTabs"] = !!boolean;
}

window.addEventListener("load", () => {

	const delayElement = document.getElementById("delay");
	const movePinnedTabsElement = document.getElementById("movePinnedTabs");

	delayElement.value = getDelay();
	movePinnedTabsElement.checked = getMovePinnedTabs();

	delayElement.addEventListener("change", ({ target }) => {
		target.value = setDelay(target.value);
	});
	movePinnedTabsElement.addEventListener("change", ({ target }) => {
		target.checked = setMovePinnedTabs(target.checked);
	});

});

}());
